<?php

class Iugu_Transfer extends APIResource {
   public static function create($attributes=Array()) { return self::createAPI($attributes); }
}
