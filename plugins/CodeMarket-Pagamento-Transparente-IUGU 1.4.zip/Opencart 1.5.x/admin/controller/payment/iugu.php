<?php

class ControllerPaymentIugu extends Controller {

    private $error = array();

    public function index() {
        $this->load->language('payment/iugu');

        $this->document->setTitle($this->language->get('heading_title_main'));

        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && ($this->validate())) {
            $this->model_setting_setting->editSetting('iugu', $this->request->post);

            $this->session->data['success'] = $this->language->get('text_success');

            $this->redirect($this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL'));
        }
        $this->data['heading_title'] = $this->language->get('heading_title_modulo');
        $this->data['text_feito'] = $this->language->get('text_feito');
        $this->data['text_enabled'] = $this->language->get('text_enabled');
        $this->data['text_disabled'] = $this->language->get('text_disabled');
        $this->data['text_all_zones'] = $this->language->get('text_all_zones');
        $this->data['text_none'] = $this->language->get('text_none');
        $this->data['text_yes'] = $this->language->get('text_yes');
        $this->data['text_no'] = $this->language->get('text_no');

        $this->data['entry_token'] = $this->language->get('entry_token');
        $this->data['entry_id'] = $this->language->get('entry_id');
        $this->data['entry_order_status'] = $this->language->get('entry_order_status');
        $this->data['entry_order_aguardando_pagamento'] = $this->language->get('entry_order_aguardando_pagamento');
        $this->data['entry_order_analise'] = $this->language->get('entry_order_analise');
        $this->data['entry_order_paga'] = $this->language->get('entry_order_paga');
        $this->data['entry_order_expirado'] = $this->language->get('entry_order_expirado');
        $this->data['entry_order_cancelada'] = $this->language->get('entry_order_cancelada');
        $this->data['entry_order_reembolsado'] = $this->language->get('entry_order_reembolsado');
        $this->data['entry_geo_zone'] = $this->language->get('entry_geo_zone');
        $this->data['entry_status'] = $this->language->get('entry_status');
        $this->data['entry_sort_order'] = $this->language->get('entry_sort_order');
        $this->data['entry_update_status_alert'] = $this->language->get('entry_update_status_alert');

        $this->data['entry_minimo_boleto'] = $this->language->get('entry_minimo_boleto');
        $this->data['entry_maximo_boleto'] = $this->language->get('entry_maximo_boleto');
        $this->data['entry_desconto_boleto'] = $this->language->get('entry_desconto_boleto');
        $this->data['entry_minimo_cartao'] = $this->language->get('entry_minimo_cartao');
        $this->data['entry_maximo_cartao'] = $this->language->get('entry_maximo_cartao');
        $this->data['entry_parcelamento'] = $this->language->get('entry_parcelamento');
        $this->data['entry_boleto'] = $this->language->get('entry_boleto');
        $this->data['entry_cartao'] = $this->language->get('entry_cartao');
        $this->data['entry_salvar_cartao'] = $this->language->get('entry_salvar_cartao');
        $this->data['entry_total_parcelas'] = $this->language->get('entry_total_parcelas');
        $this->data['entry_sem_juros'] = $this->language->get('entry_sem_juros');
        $this->data['entry_taxa_cartao'] = $this->language->get('entry_taxa_cartao');
        $this->data['entry_pular_pagamento'] = $this->language->get('entry_pular_pagamento');
        $this->data['entry_teste'] = $this->language->get('entry_teste');


        $this->data['button_save'] = $this->language->get('button_save');
        $this->data['button_cancel'] = $this->language->get('button_cancel');

        if (isset($this->error['warning'])) {
            $this->data['error_warning'] = $this->error['warning'];
        } else {
            $this->data['error_warning'] = '';
        }

        if (isset($this->error['token'])) {
            $this->data['error_token'] = $this->error['token'];
        } else {
            $this->data['error_token'] = '';
        }

        if (isset($this->error['id'])) {
            $this->data['error_id'] = $this->error['id'];
        } else {
            $this->data['error_id'] = '';
        }

        $this->data['breadcrumbs'] = array();

        $this->data['breadcrumbs'][] = array(
            'href' => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
            'text' => $this->language->get('text_home'),
            'separator' => false
        );

        $this->data['breadcrumbs'][] = array(
            'href' => $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL'),
            'text' => $this->language->get('text_payment'),
            'separator' => ' :: '
        );

        $this->data['breadcrumbs'][] = array(
            'href' => $this->url->link('payment/iugu', 'token=' . $this->session->data['token'], 'SSL'),
            'text' => $this->language->get('heading_title'),
            'separator' => ' :: '
        );

        $this->data['action'] = $this->url->link('payment/iugu', 'token=' . $this->session->data['token'], 'SSL');

        $this->data['cancel'] = $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL');

        if (isset($this->request->post['iugu_token'])) {
            $this->data['iugu_token'] = $this->request->post['iugu_token'];
        } else {
            $this->data['iugu_token'] = $this->config->get('iugu_token');
        }

        if (isset($this->request->post['iugu_id'])) {
            $this->data['iugu_id'] = $this->request->post['iugu_id'];
        } else {
            $this->data['iugu_id'] = $this->config->get('iugu_id');
        }

        if (isset($this->request->post['iugu_teste'])) {
            $this->data['iugu_teste'] = $this->request->post['iugu_teste'];
        } else {
            $this->data['iugu_teste'] = $this->config->get('iugu_teste');
        }

        if (isset($this->request->post['iugu_pular_pagamento'])) {
            $this->data['iugu_pular_pagamento'] = $this->request->post['iugu_pular_pagamento'];
        } else {
            $this->data['iugu_pular_pagamento'] = $this->config->get('iugu_pular_pagamento');
        }

        if (isset($this->request->post['iugu_taxa_cartao'])) {
            $this->data['iugu_taxa_cartao'] = $this->request->post['iugu_taxa_cartao'];
        } else {
            $this->data['iugu_taxa_cartao'] = $this->config->get('iugu_taxa_cartao');
        }

        if (isset($this->request->post['iugu_total_parcelas'])) {
            $this->data['iugu_total_parcelas'] = $this->request->post['iugu_total_parcelas'];
        } else {
            $this->data['iugu_total_parcelas'] = $this->config->get('iugu_total_parcelas');
        }

        if (isset($this->request->post['iugu_sem_juros'])) {
            $this->data['iugu_sem_juros'] = $this->request->post['iugu_sem_juros'];
        } else {
            $this->data['iugu_sem_juros'] = $this->config->get('iugu_sem_juros');
        }

        if (isset($this->request->post['iugu_minimo_boleto'])) {
            $this->data['iugu_minimo_boleto'] = $this->request->post['iugu_minimo_boleto'];
        } else {
            $this->data['iugu_minimo_boleto'] = $this->config->get('iugu_minimo_boleto');
        }

        if (isset($this->request->post['iugu_maximo_boleto'])) {
            $this->data['iugu_maximo_boleto'] = $this->request->post['iugu_maximo_boleto'];
        } else {
            $this->data['iugu_maximo_boleto'] = $this->config->get('iugu_maximo_boleto');
        }

        if (isset($this->request->post['iugu_desconto_boleto'])) {
            $this->data['iugu_desconto_boleto'] = $this->request->post['iugu_desconto_boleto'];
        } else {
            $this->data['iugu_desconto_boleto'] = $this->config->get('iugu_desconto_boleto');
        }

        if (isset($this->request->post['iugu_minimo_cartao'])) {
            $this->data['iugu_minimo_cartao'] = $this->request->post['iugu_minimo_cartao'];
        } else {
            $this->data['iugu_minimo_cartao'] = $this->config->get('iugu_minimo_cartao');
        }

        if (isset($this->request->post['iugu_maximo_cartao'])) {
            $this->data['iugu_maximo_cartao'] = $this->request->post['iugu_maximo_cartao'];
        } else {
            $this->data['iugu_maximo_cartao'] = $this->config->get('iugu_maximo_cartao');
        }


        if (isset($this->request->post['iugu_parcelamento'])) {
            $this->data['iugu_parcelamento'] = $this->request->post['iugu_parcelamento'];
        } else {
            $this->data['iugu_parcelamento'] = $this->config->get('iugu_parcelamento');
        }

        if (isset($this->request->post['iugu_boleto'])) {
            $this->data['iugu_boleto'] = $this->request->post['iugu_boleto'];
        } else {
            $this->data['iugu_boleto'] = $this->config->get('iugu_boleto');
        }

        if (isset($this->request->post['iugu_cartao'])) {
            $this->data['iugu_cartao'] = $this->request->post['iugu_cartao'];
        } else {
            $this->data['iugu_cartao'] = $this->config->get('iugu_cartao');
        }

        if (isset($this->request->post['iugu_salvar_cartao'])) {
            $this->data['iugu_salvar_cartao'] = $this->request->post['iugu_salvar_cartao'];
        } else {
            $this->data['iugu_salvar_cartao'] = $this->config->get('iugu_salvar_cartao');
        }

        if (isset($this->request->post['iugu_update_status_alert'])) {
            $this->data['iugu_update_status_alert'] = $this->request->post['iugu_update_status_alert'];
        } else {
            $this->data['iugu_update_status_alert'] = $this->config->get('iugu_update_status_alert');
        }

        if (isset($this->request->post['iugu_order_aguardando_pagamento'])) {
            $this->data['iugu_order_aguardando_pagamento'] = $this->request->post['iugu_order_aguardando_pagamento'];
        } else {
            $this->data['iugu_order_aguardando_pagamento'] = $this->config->get('iugu_order_aguardando_pagamento');
        }

        if (isset($this->request->post['iugu_order_analise'])) {
            $this->data['iugu_order_analise'] = $this->request->post['iugu_order_analise'];
        } else {
            $this->data['iugu_order_analise'] = $this->config->get('iugu_order_analise');
        }

        if (isset($this->request->post['iugu_order_paga'])) {
            $this->data['iugu_order_paga'] = $this->request->post['iugu_order_paga'];
        } else {
            $this->data['iugu_order_paga'] = $this->config->get('iugu_order_paga');
        }

        if (isset($this->request->post['iugu_order_expirado'])) {
            $this->data['iugu_order_expirado'] = $this->request->post['iugu_order_expirado'];
        } else {
            $this->data['iugu_order_expirado'] = $this->config->get('iugu_order_expirado');
        }

        if (isset($this->request->post['iugu_order_cancelada'])) {
            $this->data['iugu_order_cancelada'] = $this->request->post['iugu_order_cancelada'];
        } else {
            $this->data['iugu_order_cancelada'] = $this->config->get('iugu_order_cancelada');
        }

        if (isset($this->request->post['iugu_order_reembolsado'])) {
            $this->data['iugu_order_reembolsado'] = $this->request->post['iugu_order_reembolsado'];
        } else {
            $this->data['iugu_order_reembolsado'] = $this->config->get('iugu_order_nao_efetivado');
        }

        if (isset($this->request->post['iugu_order_status_id'])) {
            $this->data['iugu_order_status_id'] = $this->request->post['iugu_order_status_id'];
        } else {
            $this->data['iugu_order_status_id'] = $this->config->get('iugu_order_status_id');
        }

        $this->load->model('localisation/order_status');

        $this->data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

        if (isset($this->request->post['iugu_geo_zone_id'])) {
            $this->data['iugu_geo_zone_id'] = $this->request->post['iugu_geo_zone_id'];
        } else {
            $this->data['iugu_geo_zone_id'] = $this->config->get('iugu_geo_zone_id');
        }

        $this->load->model('localisation/geo_zone');

        $this->data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

        if (isset($this->request->post['iugu_status'])) {
            $this->data['iugu_status'] = $this->request->post['iugu_status'];
        } else {
            $this->data['iugu_status'] = $this->config->get('iugu_status');
        }

        if (isset($this->request->post['iugu_sort_order'])) {
            $this->data['iugu_sort_order'] = $this->request->post['iugu_sort_order'];
        } else {
            $this->data['iugu_sort_order'] = $this->config->get('iugu_sort_order');
        }

        $this->template = 'payment/iugu.tpl';
        $this->children = array(
            'common/header',
            'common/footer'
        );

        $this->response->setOutput($this->render(TRUE), $this->config->get('config_compression'));
    }

    public function install() {
        //Criando a coluna para o ID do Cliente da IUGU
        $query = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "customer` LIKE 'iugu_customer_id'");
        if (!$query->num_rows) {
            $this->db->query("ALTER TABLE `" . DB_PREFIX . "customer` ADD (`iugu_customer_id` varchar(32),`iugu_cartao_id` varchar(32))");
        }

        //Criando a coluna para o ID do Pedido da IUGU
        $query1 = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "order` LIKE 'iugu_order_id'");
        if (!$query1->num_rows) {
            $this->db->query("ALTER TABLE `" . DB_PREFIX . "order` ADD (`iugu_order_id` varchar(32),`iugu_subscription_id` varchar(32))");
        }

        //Criando a coluna assinatura_iugu e assinatura_iugu_identificador em Produto
        $query = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "product` LIKE 'assinatura_iugu'");
        if (!$query->num_rows) {
            $this->db->query("ALTER TABLE `" . DB_PREFIX . "product` ADD (`assinatura_iugu` varchar(6),`assinatura_iugu_identificador` varchar(45))");
        }
    }

    private function validate() {

        if (!$this->user->hasPermission('modify', 'payment/iugu')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if (!$this->request->post['iugu_token']) {
            $this->error['token'] = $this->language->get('error_token');
        }

        if (!$this->request->post['iugu_id']) {
            $this->error['id'] = $this->language->get('error_id');
        }

        if (!$this->error) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

}
