<?php

class Iugu_Plan extends APIResource {
  public static function create($attributes=Array()) { return self::createAPI($attributes); }
  public static function search($options=Array())    { return self::searchAPI($options); }
  public static function fetch($key)                 { return self::fetchAPI($key); }
}
