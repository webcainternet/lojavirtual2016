<?php

class ModelModuleCodemarketIuguAssinatura extends Model {

    public function Assinatura($produtos,$order_info,$cliente){
        //$this->log->write('IUGU Assinatura - Verificando se tem assinatura');
        if(!empty($produtos)){
        //$this->log->write('IUGU Assinatura - Produtos '.print_r($produtos,true));

        //$this->log->write('IUGU Assinatura - Listando Produtos');

        $plano_iugu = array();
        $preco_iugu = array();
        foreach ($produtos as $key => $row) {
        $plano_iugu[$key]  = $row['plano_iugu'];
        $preco_iugu[$key] = $row['price'];
        }

        // Ordena os dados com volume descendente, edition ascendente
        // adiciona $data como o último parãmetro, para ordenar pela chave comum
        array_multisort($plano_iugu, SORT_DESC, $preco_iugu, SORT_DESC, $produtos);
        //$this->log->write('IUGU Assinatura - Produtos Ordenados pelo Plano Iugu e Preco '.print_r($produtos,true));

        foreach ($produtos as $product) {


        if(!empty($product['plano_iugu'])){

        if((empty($plano_iugu1)) OR ($plano_iugu1 == $product['plano_iugu']) ){
        $plano_iugu1 = $product['plano_iugu'];
        $options_names = '';
        foreach ($product['option'] as $option) {
        $options_names .= ' - ' . $option['name'] . ': ' . $option['option_value'];
        }
        //Até 80 caracteres para a descrição do Produto
        $description = mb_substr($product['name'] . $options_names, 0, 80, 'UTF-8');
        if (($this->currency->format($product['price'], $order_info['currency_code'], false, false) * 100) >= 1) {
        $item1[] = array(
        'description' => $description,
        'quantity' => $product['quantity'],
        'recurrent' => true,
        'price_cents' => $this->currency->format($product['price'], $order_info['currency_code'], false, false) * 100
        );
        }

        }elseif((empty($plano_iugu2)) OR ($plano_iugu2 == $product['plano_iugu'])){
        $plano_iugu2= $product['plano_iugu'];
        $options_names = '';
        foreach ($product['option'] as $option) {
        $options_names .= ' - ' . $option['name'] . ': ' . $option['option_value'];
        }
        //Até 80 caracteres para a descrição do Produto
        $description = mb_substr($product['name'] . $options_names, 0, 80, 'UTF-8');
        if (($this->currency->format($product['price'], $order_info['currency_code'], false, false) * 100) >= 1) {
        $item2[] = array(
        'description' => $description,
        'quantity' => $product['quantity'],
        'recurrent' => true,
        'price_cents' => $this->currency->format($product['price'], $order_info['currency_code'], false, false) * 100
        );
        }

        }elseif((empty($plano_iugu3)) OR ($plano_iugu3 == $product['plano_iugu'])){
        $plano_iugu3 = $product['plano_iugu'];
        $options_names = '';
        foreach ($product['option'] as $option) {
        $options_names .= ' - ' . $option['name'] . ': ' . $option['option_value'];
        }
        //Até 80 caracteres para a descrição do Produto
        $description = mb_substr($product['name'] . $options_names, 0, 80, 'UTF-8');
        if (($this->currency->format($product['price'], $order_info['currency_code'], false, false) * 100) >= 1) {
        $item3[] = array(
        'description' => $description,
        'quantity' => $product['quantity'],
        'recurrent' => true,
        'price_cents' => $this->currency->format($product['price'], $order_info['currency_code'], false, false) * 100
        );
        }
        }

        }

        }

        //$this->log->write('IUGU Assinatura - Fim Listando Produtos');
        $plano_iugu1 = explode("CODEMARKET", $plano_iugu1);
        $intervalo = Iugu_Plan::fetch($plano_iugu1[1]);
        if((!empty($intervalo)) and (!empty($item1))){
        $intervalo = $intervalo->interval_type;
        if($intervalo == 'weeks' ){
        $intervalo = 7;
        }else {
        $intervalo = 30;
        }

        //$this->log->write('IUGU Assinatura - Intervalo da Assinatura 1 '.$intervalo);

        $assinatura1 = Iugu_Subscription::create(Array(
        "plan_identifier" => $plano_iugu1[0],
        "customer_id" => $cliente['id'],
        "expires_at" => date('Y-m-d', strtotime("+".$intervalo." days")),
        "subitems" => $item1
        ));

        //$this->log->write('IUGU Assinatura - Assinatura 1 Criada '.print_r($assinatura1,true));

        }

        if(!empty($item2)){
        $plano_iugu2 = explode("CODEMARKET", $plano_iugu2);
        $intervalo = Iugu_Plan::fetch($plano_iugu2[1]);
        if((!empty($intervalo)) and (!empty($item))){
        $intervalo = $intervalo->interval_type;
        if($intervalo == 'weeks' ){
        $intervalo = 7;
        }else {
        $intervalo = 30;
        }

        Iugu_Subscription::create(Array(
        "plan_identifier" => $plano_iugu2[0],
        "customer_id" => $cliente['id'],
        "expires_at" => date('Y-m-d', strtotime("+".$intervalo." days")),
        "subitems" => $item2
        ));
        }
        }

        if(!empty($item3)){
        $plano_iugu3 = explode("CODEMARKET", $plano_iugu3);

        $intervalo = Iugu_Plan::fetch($plano_iugu3[1]);
        if((!empty($intervalo)) and (!empty($item))){
        $intervalo = $intervalo->interval_type;
        if($intervalo == 'weeks' ){
        $intervalo = 7;
        }else {
        $intervalo = 30;
        }

        Iugu_Subscription::create(Array(
        "plan_identifier" => $plano_iugu3[0],
        "customer_id" => $cliente['id'],
        "expires_at" => date('Y-m-d', strtotime("+".$intervalo." days")),
        "subitems" => $item3
        ));
        }
        }
        }
    }

}
