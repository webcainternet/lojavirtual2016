<?php
$_['text_title'] 				= 'PagSeguro';
$_['button_confirm_pagseguro'] 	= 'Confirmar e ir para o PagSeguro';
$_['text_extra_amount']			= 'Frete e Taxas';
?>