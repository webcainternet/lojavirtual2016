﻿How to install 

step 1: Login in to Dashboard
step 2: Extensions -> Extension Installer
step 3: click upload and select file html_minifier.ocmod.zip and click Upload

if u get error Invalid file 

then go to System ->Settings

click edit store 

go to server tab

check "Allowed File Mime Types" it should have "application/x-zip-compressed" if it is not there then you need to 
add it and click save

once you have done this you can go to Step 2: now